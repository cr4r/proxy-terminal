package muhammadfajriseptiandwicahyo.ti4a.uts.up2u;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnGenerateCode, btnRegister;
    private EditText etNamaLengkap, etNomorTelepon;
    private TextView tvPembangkitKode;
    private String generateCode(String nama, String noTelepon) {
        int uniqNumber = 0;
        String initialName[] = nama.split(" ");
        String newInitial = "";

        for (int j = 0; j < initialName.length; j++) {
            newInitial = newInitial + initialName[j].charAt(0);
        }

        for (int i = 0;i < noTelepon.length(); i++) {
            int getDigit = Integer.parseInt(String.valueOf(noTelepon.charAt(i)));

            if (getDigit % 2 != 0)
                uniqNumber = uniqNumber + getDigit;
        }

        return newInitial + uniqNumber;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNamaLengkap = findViewById(R.id.et_nama_lengkap);
        etNomorTelepon = findViewById(R.id.et_nomor_telepon);

        btnGenerateCode = findViewById(R.id.btn_generate_code);
        btnRegister = findViewById(R.id.btn_register);

        tvPembangkitKode = findViewById(R.id.tv_pembangkit_kode);



        btnGenerateCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama =etNamaLengkap.getText().toString();
                String noTelepon = etNomorTelepon.getText().toString();

                if (nama.trim().isEmpty()){
                    etNamaLengkap.setError("Nama Harus di isi");
                }
                if (noTelepon.trim().isEmpty()){
                    etNomorTelepon.setError("Nama Harus di isi");
                }
                else{
                    tvPembangkitKode.setText(generateCode(nama,noTelepon));
                }
            }
        });

    }
}